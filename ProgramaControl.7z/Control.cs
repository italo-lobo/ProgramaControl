﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaDNI
{

   

    public partial class formControl : Form
    {
        List<int> validados = new List<int>();
        List<int> siEnRevision = new List<int>();
        List<int> contestador = new List<int>(); 
        List<int> desiste= new List<int>();
        List<int> duplicado = new List<int>();
        int contadorValidados = 0;
        int contadorContestador = 0;
        int contadorRevision = 0;
        int contadorDesiste = 0;
        int contadorDuplicado = 0;
        int contadorNoAplica = 0;
        //int lm=0;

        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public formControl()
        {
            InitializeComponent();
        }

     

        //QUIERO AGREGAR MI CODIGO A UN METODO PERO NO ENCUENTRO LA FORMA DE AGREGAR LOS PARAMETROS. 
        //EL PARAMETRO QUE CAMBIARIA SOLO SERIA EL DE LISTxxxx
        
        //listValidados.Items.Add(txtDNI.Text);

        // void CargarDato( string lista)
        //{
        //    try
        //    {
        //        lista;
        //        txtDNI.Text = "";
        //        txtDNI.Focus();
        //    //    contadorValidados++;
        //    //    lblValdCont.Text = Convert.ToString(contadorValidados);
        //    //}
        //    catch (Exception)
        //    {

        //        MessageBox.Show("solo puede ingresar numeros y el campo no puede estar vacio");
        //        txtDNI.Text = "";
        //        txtDNI.Focus();
        //    }
        //}

       
        //PROGRAMACION DE BOTONES PARA AGREGAR CONTENIDO (VALIDADO Y CONTESTADOR)

        private void btnValidado_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    listValidados.Items.Add(txtDNI.Text);
                    txtDNI.Text = "";
                    txtDNI.Focus();
                    contadorValidados++;
                    lblValdCont.Text = Convert.ToString(contadorValidados);                }
                catch (Exception)
                {

                    MessageBox.Show("solo puede ingresar numeros y el campo no puede estar vacio");
                    txtDNI.Text = "";
                    txtDNI.Focus();
                }

            }
        }
        private void btnContestador_Click(object sender, EventArgs e)
        {
            try
            {
                lstConts.Items.Add(txtDNI.Text);
                txtDNI.Text = "";
                txtDNI.Focus();
                contadorContestador++;
                lblContsCont.Text = Convert.ToString(contadorContestador);
                //codigo anterior +++++++++++++++++++++++++++++
                //servia para agregar linea de texto a un label que cumplia la funcion de lista 

                //contestador.Add(Convert.ToInt32(txtDNI.Text));
                //lblContestList.Text = lblContestList.Text + "\n" + txtDNI.Text ;
                //txtDNI.Text = "";
                //txtDNI.Focus();
                //contadorContestador++;
                //lblContsCont.Text = Convert.ToString(contadorContestador);

            }
            catch (Exception)
            {

                MessageBox.Show("solo puede ingresar numeros y el campo no puede estar vacio");
                txtDNI.Text = "";
                txtDNI.Focus();
            }
        }


        private void btnRevision_Click(object sender, EventArgs e)
        {

            try
            {
                lstRev.Items.Add(txtDNI.Text);
                txtDNI.Text = "";
                txtDNI.Focus();
                contadorRevision++;
                lblValdCont.Text = Convert.ToString(contadorRevision);
            }
            catch (Exception)
            {

                MessageBox.Show("solo puede ingresar numeros y el campo no puede estar vacio");
                txtDNI.Text = "";
                txtDNI.Focus();
            }


        }

        private void btnDesiste_Click(object sender, EventArgs e)

        {

            try
            {
                lstDesis.Items.Add(txtDNI.Text);
                txtDNI.Text = "";
                txtDNI.Focus();
                contadorDesiste++;
                lblValdCont.Text = Convert.ToString(contadorDesiste);
            }
            catch (Exception)
            {

                MessageBox.Show("solo puede ingresar numeros y el campo no puede estar vacio");
                txtDNI.Text = "";
                txtDNI.Focus();
            }


        }

        private void btnDupli_Click(object sender, EventArgs e)
        {
            try
            {
                lstDupli.Items.Add(txtDNI.Text);
                txtDNI.Text = "";
                txtDNI.Focus();
                contadorDuplicado++;
                lblValdCont.Text = Convert.ToString(contadorDuplicado);
            }
            catch (Exception)
            {

                MessageBox.Show("solo puede ingresar numeros y el campo no puede estar vacio");
                txtDNI.Text = "";
                txtDNI.Focus();
            }

        }

        private void btnNoApli_Click(object sender, EventArgs e)
        {
            try
            {
                lstNoApl.Items.Add(txtDNI.Text);
                txtDNI.Text = "";
                txtDNI.Focus();
                contadorNoAplica++;
                lblValdCont.Text = Convert.ToString(contadorNoAplica);
            }
            catch (Exception)
            {

                MessageBox.Show("solo puede ingresar numeros y el campo no puede estar vacio");
                txtDNI.Text = "";
                txtDNI.Focus();
            }
        }



        //PROGRAMACION DE BOTONES CON FUNCIONES COPIAR/ELIMINAR/MODIFICAR
        private void btnCopiar_Click(object sender, EventArgs e)
        {
            //ESTA PARTE DEL CODIGO COPIA AL PORTAPAPELES LA INFO QUE TENGO EN TODO EL PROGRAMA
            //LA FINALIDAD ES PASARLO A UN EXCEL O IMPRIMIR UN REPORTE - FALTA TERMINAR ESTO 
            //string totales = $("total de cargas: Validados {0} Contestador {1} Si en revision {2} Desiste {3} Duplicadas {4}"; lblValdCont.Text,lblContsCont.Text);
                //lblContsCont.Text, lblRevCont.Text, lblDesisCont.Text, lblDuplCont.Text;
         //Clipboard.SetText(lblValiList.Text + "\n" + lblContestList.Text + "\n" );
           
        }
       
        private void btnEliminar_Click(object sender, EventArgs e)
        {

             int indice=listValidados.SelectedIndex;
            listValidados.Items.RemoveAt(indice);
            //DODO ERROR: AGREGAR CODIGO PARA QUE ME RESTE DEL CONTADOR CUANDO ELIMINO 

        }
        private void btnModf_Click(object sender, EventArgs e)
        {
            //ESTA PARTE DEL CODIGO SERIA PARA QUE ME MODIFIQUE LO QUE NECESITO SEGUN EL LISTBOX QUE TENGA SELECCIONADO 
            //Podria simplificarlo con un metodo y un switch? 
            //SOLO LO PROGRAME PARA VALIDADOS Y CONTESTADOR
            if (listValidados.SelectedIndex > -1)
            {
                int indice = listValidados.SelectedIndex;
                listValidados.Items.RemoveAt(indice);
                listValidados.Items.Insert(indice, txtDNI.Text);
                txtDNI.Text = "";
                txtDNI.Focus();
            }
            if (lstConts.SelectedIndex > -1)
            {
                int indice = lstConts.SelectedIndex;
                lstConts.Items.RemoveAt(indice);
                lstConts.Items.Insert(indice, txtDNI.Text);
                txtDNI.Text = "";
                txtDNI.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Codigo que funciona. (SIMPLIFICAR)  
            //string lmensualString = "";
            //lmensualString = txtLM.Text;
            //int tamañoLM= lmensualString.Length -5;
            //lblTamañoLM.Text = tamañoLM.ToString();
            //lblLimiteMensual.Text = lmensualString.Substring(0,tamañoLM);



            //Recordar eliminar lblLimiteMensual(esto va a quedar en Clipboar)
            //INGRESAR ESTE CODIGO EN UN METODO 

            //int tamañoLM = txtLM.Text.Length - 5;
            //lblLimiteMensual.Text = txtLM.Text.Substring(0, tamañoLM);
            //int calculoLZ = Convert.ToInt32(lblLimiteMensual.Text) *3;
            //lblLz.Text = calculoLZ.ToString();
           
            
            //***************************************************
            //tercer intento mas simplificado         
            int tamañoLM = txtLM.Text.Length - 5;
            int tamañoLPL = txtLPL.Text.Length - 5;
            txtLPL.Text = txtLPL.Text.Substring(0, tamañoLPL);
            txtLM.Text = txtLM.Text.Substring(0, tamañoLM);
            txtLZ.Text =Convert.ToString (Convert.ToInt32(txtLM.Text) * 3);
            //copiado al portapeles 
            Clipboard.SetText("LM:$"+txtLM.Text+" LZ:$"+txtLZ.Text+" LPL:$"+txtLPL.Text);
           


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtLM.Text = "";
            txtLZ.Text = "";
            txtLPL.Text = "";

        }
    }
}
    

