﻿namespace ListaDNI
{
    partial class formControl
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formControl));
            this.btnValidado = new System.Windows.Forms.Button();
            this.txtDNI = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblValdCont = new System.Windows.Forms.Label();
            this.btnCopiar = new System.Windows.Forms.Button();
            this.btnContestador = new System.Windows.Forms.Button();
            this.btnRevision = new System.Windows.Forms.Button();
            this.btnDesiste = new System.Windows.Forms.Button();
            this.btnDupli = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblDuplCont = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblDesisCont = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblRevCont = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblContsCont = new System.Windows.Forms.Label();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnModf = new System.Windows.Forms.Button();
            this.lstConts = new System.Windows.Forms.ListBox();
            this.listValidados = new System.Windows.Forms.ListBox();
            this.lstRev = new System.Windows.Forms.ListBox();
            this.lstDesis = new System.Windows.Forms.ListBox();
            this.lstDupli = new System.Windows.Forms.ListBox();
            this.lstNoApl = new System.Windows.Forms.ListBox();
            this.btnNoApli = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtLM = new System.Windows.Forms.TextBox();
            this.txtLPL = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtLZ = new System.Windows.Forms.TextBox();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnValidado
            // 
            this.btnValidado.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnValidado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnValidado.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.btnValidado.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.btnValidado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnValidado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValidado.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnValidado.Location = new System.Drawing.Point(17, 53);
            this.btnValidado.Name = "btnValidado";
            this.btnValidado.Size = new System.Drawing.Size(120, 23);
            this.btnValidado.TabIndex = 0;
            this.btnValidado.Text = "VALIDADO";
            this.btnValidado.UseVisualStyleBackColor = false;
            this.btnValidado.Click += new System.EventHandler(this.btnValidado_Click);
            // 
            // txtDNI
            // 
            this.txtDNI.Location = new System.Drawing.Point(281, 23);
            this.txtDNI.Name = "txtDNI";
            this.txtDNI.Size = new System.Drawing.Size(151, 20);
            this.txtDNI.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "VALD";
            // 
            // lblValdCont
            // 
            this.lblValdCont.AutoSize = true;
            this.lblValdCont.Location = new System.Drawing.Point(77, 10);
            this.lblValdCont.Name = "lblValdCont";
            this.lblValdCont.Size = new System.Drawing.Size(15, 13);
            this.lblValdCont.TabIndex = 4;
            this.lblValdCont.Text = "N";
            // 
            // btnCopiar
            // 
            this.btnCopiar.Location = new System.Drawing.Point(17, 23);
            this.btnCopiar.Name = "btnCopiar";
            this.btnCopiar.Size = new System.Drawing.Size(75, 23);
            this.btnCopiar.TabIndex = 5;
            this.btnCopiar.Text = "COPIAR";
            this.btnCopiar.UseVisualStyleBackColor = true;
            this.btnCopiar.Click += new System.EventHandler(this.btnCopiar_Click);
            // 
            // btnContestador
            // 
            this.btnContestador.BackColor = System.Drawing.Color.DarkOrange;
            this.btnContestador.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnContestador.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.btnContestador.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContestador.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContestador.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnContestador.Location = new System.Drawing.Point(17, 81);
            this.btnContestador.Name = "btnContestador";
            this.btnContestador.Size = new System.Drawing.Size(120, 23);
            this.btnContestador.TabIndex = 6;
            this.btnContestador.Text = "CONTESTADOR";
            this.btnContestador.UseVisualStyleBackColor = false;
            this.btnContestador.Click += new System.EventHandler(this.btnContestador_Click);
            // 
            // btnRevision
            // 
            this.btnRevision.BackColor = System.Drawing.Color.DarkOrange;
            this.btnRevision.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRevision.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.btnRevision.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRevision.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnRevision.Location = new System.Drawing.Point(17, 109);
            this.btnRevision.Name = "btnRevision";
            this.btnRevision.Size = new System.Drawing.Size(120, 23);
            this.btnRevision.TabIndex = 7;
            this.btnRevision.Text = "REVISION";
            this.btnRevision.UseVisualStyleBackColor = false;
            this.btnRevision.Click += new System.EventHandler(this.btnRevision_Click);
            // 
            // btnDesiste
            // 
            this.btnDesiste.BackColor = System.Drawing.Color.Crimson;
            this.btnDesiste.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDesiste.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.btnDesiste.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDesiste.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesiste.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDesiste.Location = new System.Drawing.Point(143, 53);
            this.btnDesiste.Name = "btnDesiste";
            this.btnDesiste.Size = new System.Drawing.Size(120, 23);
            this.btnDesiste.TabIndex = 8;
            this.btnDesiste.Text = "DESISTE";
            this.btnDesiste.UseVisualStyleBackColor = false;
            this.btnDesiste.Click += new System.EventHandler(this.btnDesiste_Click);
            // 
            // btnDupli
            // 
            this.btnDupli.BackColor = System.Drawing.Color.Crimson;
            this.btnDupli.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDupli.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.btnDupli.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDupli.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDupli.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDupli.Location = new System.Drawing.Point(143, 81);
            this.btnDupli.Name = "btnDupli";
            this.btnDupli.Size = new System.Drawing.Size(120, 23);
            this.btnDupli.TabIndex = 9;
            this.btnDupli.Text = "DUPLICADA";
            this.btnDupli.UseVisualStyleBackColor = false;
            this.btnDupli.Click += new System.EventHandler(this.btnDupli_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "CONTS";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblDuplCont);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.lblDesisCont);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.lblRevCont);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.lblContsCont);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lblValdCont);
            this.panel1.Location = new System.Drawing.Point(559, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(199, 93);
            this.panel1.TabIndex = 11;
            // 
            // lblDuplCont
            // 
            this.lblDuplCont.AutoSize = true;
            this.lblDuplCont.Location = new System.Drawing.Point(167, 37);
            this.lblDuplCont.Name = "lblDuplCont";
            this.lblDuplCont.Size = new System.Drawing.Size(15, 13);
            this.lblDuplCont.TabIndex = 17;
            this.lblDuplCont.Text = "N";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(108, 37);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "DUPL";
            // 
            // lblDesisCont
            // 
            this.lblDesisCont.AutoSize = true;
            this.lblDesisCont.Location = new System.Drawing.Point(167, 11);
            this.lblDesisCont.Name = "lblDesisCont";
            this.lblDesisCont.Size = new System.Drawing.Size(15, 13);
            this.lblDesisCont.TabIndex = 15;
            this.lblDesisCont.Text = "N";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(108, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "DESIS";
            // 
            // lblRevCont
            // 
            this.lblRevCont.AutoSize = true;
            this.lblRevCont.Location = new System.Drawing.Point(77, 62);
            this.lblRevCont.Name = "lblRevCont";
            this.lblRevCont.Size = new System.Drawing.Size(15, 13);
            this.lblRevCont.TabIndex = 13;
            this.lblRevCont.Text = "N";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "REV";
            // 
            // lblContsCont
            // 
            this.lblContsCont.AutoSize = true;
            this.lblContsCont.Location = new System.Drawing.Point(77, 36);
            this.lblContsCont.Name = "lblContsCont";
            this.lblContsCont.Size = new System.Drawing.Size(15, 13);
            this.lblContsCont.TabIndex = 11;
            this.lblContsCont.Text = "N";
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(102, 23);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 23);
            this.btnEliminar.TabIndex = 14;
            this.btnEliminar.Text = "ELIMINAR";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnModf
            // 
            this.btnModf.Location = new System.Drawing.Point(187, 24);
            this.btnModf.Name = "btnModf";
            this.btnModf.Size = new System.Drawing.Size(75, 23);
            this.btnModf.TabIndex = 15;
            this.btnModf.Text = "MODIFICAR";
            this.btnModf.UseVisualStyleBackColor = true;
            this.btnModf.Click += new System.EventHandler(this.btnModf_Click);
            // 
            // lstConts
            // 
            this.lstConts.BackColor = System.Drawing.Color.DarkOrange;
            this.lstConts.FormattingEnabled = true;
            this.lstConts.Location = new System.Drawing.Point(133, 315);
            this.lstConts.Name = "lstConts";
            this.lstConts.Size = new System.Drawing.Size(120, 316);
            this.lstConts.TabIndex = 16;
            // 
            // listValidados
            // 
            this.listValidados.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.listValidados.ForeColor = System.Drawing.SystemColors.WindowText;
            this.listValidados.FormattingEnabled = true;
            this.listValidados.Location = new System.Drawing.Point(7, 315);
            this.listValidados.Name = "listValidados";
            this.listValidados.Size = new System.Drawing.Size(120, 316);
            this.listValidados.TabIndex = 13;
            // 
            // lstRev
            // 
            this.lstRev.BackColor = System.Drawing.Color.DarkOrange;
            this.lstRev.FormattingEnabled = true;
            this.lstRev.Location = new System.Drawing.Point(259, 315);
            this.lstRev.Name = "lstRev";
            this.lstRev.Size = new System.Drawing.Size(120, 316);
            this.lstRev.TabIndex = 17;
            // 
            // lstDesis
            // 
            this.lstDesis.BackColor = System.Drawing.Color.Crimson;
            this.lstDesis.FormattingEnabled = true;
            this.lstDesis.Location = new System.Drawing.Point(385, 315);
            this.lstDesis.Name = "lstDesis";
            this.lstDesis.Size = new System.Drawing.Size(120, 316);
            this.lstDesis.TabIndex = 18;
            // 
            // lstDupli
            // 
            this.lstDupli.BackColor = System.Drawing.Color.Crimson;
            this.lstDupli.FormattingEnabled = true;
            this.lstDupli.Location = new System.Drawing.Point(511, 315);
            this.lstDupli.Name = "lstDupli";
            this.lstDupli.Size = new System.Drawing.Size(120, 316);
            this.lstDupli.TabIndex = 19;
            // 
            // lstNoApl
            // 
            this.lstNoApl.BackColor = System.Drawing.Color.Crimson;
            this.lstNoApl.FormattingEnabled = true;
            this.lstNoApl.Location = new System.Drawing.Point(637, 315);
            this.lstNoApl.Name = "lstNoApl";
            this.lstNoApl.Size = new System.Drawing.Size(120, 316);
            this.lstNoApl.TabIndex = 20;
            // 
            // btnNoApli
            // 
            this.btnNoApli.BackColor = System.Drawing.Color.Crimson;
            this.btnNoApli.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNoApli.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.btnNoApli.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNoApli.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNoApli.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnNoApli.Location = new System.Drawing.Point(143, 110);
            this.btnNoApli.Name = "btnNoApli";
            this.btnNoApli.Size = new System.Drawing.Size(120, 23);
            this.btnNoApli.TabIndex = 21;
            this.btnNoApli.Text = "NO APLICA";
            this.btnNoApli.UseVisualStyleBackColor = false;
            this.btnNoApli.Click += new System.EventHandler(this.btnNoApli_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(8, 299);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 22;
            this.label1.Text = "VALIDADOS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Crimson;
            this.label4.Location = new System.Drawing.Point(383, 299);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 15);
            this.label4.TabIndex = 23;
            this.label4.Text = "DESISTE";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Crimson;
            this.label6.Location = new System.Drawing.Point(508, 299);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 15);
            this.label6.TabIndex = 24;
            this.label6.Text = "DUPLICADOS";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Crimson;
            this.label8.Location = new System.Drawing.Point(634, 299);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 15);
            this.label8.TabIndex = 25;
            this.label8.Text = "NO APLICAN";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DarkOrange;
            this.label10.Location = new System.Drawing.Point(130, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 15);
            this.label10.TabIndex = 26;
            this.label10.Text = "CONTESTADOR";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkOrange;
            this.label11.Location = new System.Drawing.Point(256, 299);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 15);
            this.label11.TabIndex = 27;
            this.label11.Text = "REVISION";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(314, 637);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 28;
            this.button1.Text = "CERRAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtLM
            // 
            this.txtLM.Location = new System.Drawing.Point(3, 51);
            this.txtLM.Name = "txtLM";
            this.txtLM.Size = new System.Drawing.Size(100, 20);
            this.txtLM.TabIndex = 29;
            // 
            // txtLPL
            // 
            this.txtLPL.Location = new System.Drawing.Point(239, 51);
            this.txtLPL.Name = "txtLPL";
            this.txtLPL.Size = new System.Drawing.Size(100, 20);
            this.txtLPL.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label12.Location = new System.Drawing.Point(42, 36);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 15);
            this.label12.TabIndex = 32;
            this.label12.Text = "LM";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label14.Location = new System.Drawing.Point(282, 36);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(32, 15);
            this.label14.TabIndex = 34;
            this.label14.Text = "LPL";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(3, 3);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 36;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label13.Location = new System.Drawing.Point(162, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 15);
            this.label13.TabIndex = 39;
            this.label13.Text = "LZ";
            // 
            // txtLZ
            // 
            this.txtLZ.Enabled = false;
            this.txtLZ.Location = new System.Drawing.Point(121, 51);
            this.txtLZ.Name = "txtLZ";
            this.txtLZ.Size = new System.Drawing.Size(100, 20);
            this.txtLZ.TabIndex = 38;
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(84, 3);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiar.TabIndex = 40;
            this.btnLimpiar.Text = "LIMPIAR";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnCalcular);
            this.panel2.Controls.Add(this.btnLimpiar);
            this.panel2.Controls.Add(this.txtLM);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.txtLPL);
            this.panel2.Controls.Add(this.txtLZ);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Location = new System.Drawing.Point(409, 203);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(348, 82);
            this.panel2.TabIndex = 41;
            // 
            // formControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(766, 669);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnNoApli);
            this.Controls.Add(this.lstNoApl);
            this.Controls.Add(this.lstDupli);
            this.Controls.Add(this.lstDesis);
            this.Controls.Add(this.lstRev);
            this.Controls.Add(this.lstConts);
            this.Controls.Add(this.btnModf);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.listValidados);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnDupli);
            this.Controls.Add(this.btnDesiste);
            this.Controls.Add(this.btnRevision);
            this.Controls.Add(this.btnContestador);
            this.Controls.Add(this.btnCopiar);
            this.Controls.Add(this.txtDNI);
            this.Controls.Add(this.btnValidado);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formControl";
            this.Text = "CONTROL DE GESTIONES DIARIAS ITALO L";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnValidado;
        private System.Windows.Forms.TextBox txtDNI;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblValdCont;
        private System.Windows.Forms.Button btnCopiar;
        private System.Windows.Forms.Button btnContestador;
        private System.Windows.Forms.Button btnRevision;
        private System.Windows.Forms.Button btnDesiste;
        private System.Windows.Forms.Button btnDupli;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblDuplCont;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblDesisCont;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblRevCont;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblContsCont;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnModf;
        private System.Windows.Forms.ListBox lstConts;
        private System.Windows.Forms.ListBox listValidados;
        private System.Windows.Forms.ListBox lstRev;
        private System.Windows.Forms.ListBox lstDesis;
        private System.Windows.Forms.ListBox lstDupli;
        private System.Windows.Forms.ListBox lstNoApl;
        private System.Windows.Forms.Button btnNoApli;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtLM;
        private System.Windows.Forms.TextBox txtLPL;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtLZ;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Panel panel2;
    }
}

